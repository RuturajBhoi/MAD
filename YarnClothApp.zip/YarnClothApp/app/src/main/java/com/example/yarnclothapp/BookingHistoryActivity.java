package com.example.yarnclothapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class BookingHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_history);
        setTitle("Booking History");

        DatabaseHelper db = new DatabaseHelper(this);
        ListView lvHistory = findViewById(R.id.lvHistory);

        SharedPreferences prefs = getSharedPreferences("session", MODE_PRIVATE);
        int userId = prefs.getInt("user_id", -1);

        List<String[]> bookings = db.getBookingsByUser(userId);

        if (bookings.isEmpty()) {
            Toast.makeText(this, "No bookings found.", Toast.LENGTH_SHORT).show();
        }

        List<String> displayList = new ArrayList<>();
        for (String[] b : bookings) {
            // b: [booking_id, user_id, product_id, product_type, quantity, total_price, payment_status, booking_date]
            displayList.add("📦 Booking #" + b[0] +
                            "\nProduct: " + b[3] + " (ID:" + b[2] + ")" +
                            "  |  Qty: " + b[4] +
                            "\nTotal: ₹" + b[5] + "  |  " + b[6] +
                            "\nDate: " + b[7]);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, displayList);
        lvHistory.setAdapter(adapter);
    }
}
