package com.example.yarnclothapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        SharedPreferences prefs = getSharedPreferences("session", MODE_PRIVATE);
        String userName = prefs.getString("user_name", "User");

        TextView tvWelcome = findViewById(R.id.tvWelcome);
        tvWelcome.setText("Welcome, " + userName + "! 👋");

        Button btnYarn    = findViewById(R.id.btnYarn);
        Button btnCloth   = findViewById(R.id.btnCloth);
        Button btnCart    = findViewById(R.id.btnCart);
        Button btnHistory = findViewById(R.id.btnHistory);
        Button btnLogout  = findViewById(R.id.btnLogout);

        btnYarn.setOnClickListener(v ->
                startActivity(new Intent(this, YarnProductActivity.class)));

        btnCloth.setOnClickListener(v ->
                startActivity(new Intent(this, ClothProductActivity.class)));

        btnCart.setOnClickListener(v ->
                startActivity(new Intent(this, CartActivity.class)));

        btnHistory.setOnClickListener(v ->
                startActivity(new Intent(this, BookingHistoryActivity.class)));

        btnLogout.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            CartManager.getInstance().clear();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}
