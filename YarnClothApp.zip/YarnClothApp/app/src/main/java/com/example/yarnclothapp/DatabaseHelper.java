package com.example.yarnclothapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "YarnClothDB";
    private static final int DB_VERSION = 1;

    // Table names
    public static final String TABLE_USER    = "users";
    public static final String TABLE_YARN    = "yarn";
    public static final String TABLE_CLOTH   = "cloth";
    public static final String TABLE_BOOKING = "bookings";
    public static final String TABLE_PAYMENT = "payments";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + TABLE_USER + " (" +
                "user_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "mobile TEXT," +
                "email TEXT UNIQUE," +
                "password TEXT," +
                "address TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_YARN + " (" +
                "yarn_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "yarn_name TEXT," +
                "yarn_type TEXT," +
                "quantity REAL," +
                "price REAL)");

        db.execSQL("CREATE TABLE " + TABLE_CLOTH + " (" +
                "cloth_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "cloth_name TEXT," +
                "cloth_type TEXT," +
                "size TEXT," +
                "price REAL)");

        db.execSQL("CREATE TABLE " + TABLE_BOOKING + " (" +
                "booking_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER," +
                "product_id INTEGER," +
                "product_type TEXT," +
                "quantity INTEGER," +
                "total_price REAL," +
                "payment_status TEXT," +
                "booking_date TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_PAYMENT + " (" +
                "payment_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER," +
                "booking_id INTEGER," +
                "payment_method TEXT," +
                "amount REAL," +
                "payment_status TEXT," +
                "payment_date TEXT)");


        db.execSQL("INSERT INTO " + TABLE_YARN + " (yarn_name,yarn_type,quantity,price) VALUES ('Cotton Yarn','Cotton',100,250)");
        db.execSQL("INSERT INTO " + TABLE_YARN + " (yarn_name,yarn_type,quantity,price) VALUES ('Silk Yarn','Silk',50,600)");
        db.execSQL("INSERT INTO " + TABLE_YARN + " (yarn_name,yarn_type,quantity,price) VALUES ('Wool Yarn','Wool',80,400)");
        db.execSQL("INSERT INTO " + TABLE_YARN + " (yarn_name,yarn_type,quantity,price) VALUES ('Polyester Yarn','Polyester',200,150)");


        db.execSQL("INSERT INTO " + TABLE_CLOTH + " (cloth_name,cloth_type,size,price) VALUES ('Cotton Cloth','Cotton','1 Meter',180)");
        db.execSQL("INSERT INTO " + TABLE_CLOTH + " (cloth_name,cloth_type,size,price) VALUES ('Silk Saree Cloth','Silk','6 Meters',1500)");
        db.execSQL("INSERT INTO " + TABLE_CLOTH + " (cloth_name,cloth_type,size,price) VALUES ('Denim Cloth','Denim','1 Meter',350)");
        db.execSQL("INSERT INTO " + TABLE_CLOTH + " (cloth_name,cloth_type,size,price) VALUES ('Linen Cloth','Linen','1 Meter',280)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_YARN);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CLOTH);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKING);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PAYMENT);
        onCreate(db);
    }


    public boolean registerUser(String name, String mobile, String email, String password, String address) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("mobile", mobile);
        cv.put("email", email);
        cv.put("password", password);
        cv.put("address", address);
        long result = db.insert(TABLE_USER, null, cv);
        return result != -1;
    }

    public Cursor loginUser(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USER +
                " WHERE (email=? OR mobile=?) AND password=?",
                new String[]{email, email, password});
    }

    public String getUserName(int userId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT name FROM " + TABLE_USER + " WHERE user_id=?",
                new String[]{String.valueOf(userId)});
        if (c.moveToFirst()) {
            String name = c.getString(0);
            c.close();
            return name;
        }
        c.close();
        return "User";
    }


    public List<String[]> getAllYarn() {
        List<String[]> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_YARN, null);
        while (c.moveToNext()) {
            list.add(new String[]{
                c.getString(0), c.getString(1), c.getString(2),
                c.getString(3), c.getString(4)
            });
        }
        c.close();
        return list;
    }

    public boolean addYarn(String name, String type, double qty, double price) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("yarn_name", name);
        cv.put("yarn_type", type);
        cv.put("quantity", qty);
        cv.put("price", price);
        return db.insert(TABLE_YARN, null, cv) != -1;
    }


    public List<String[]> getAllCloth() {
        List<String[]> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_CLOTH, null);
        while (c.moveToNext()) {
            list.add(new String[]{
                c.getString(0), c.getString(1), c.getString(2),
                c.getString(3), c.getString(4)
            });
        }
        c.close();
        return list;
    }

    public boolean addCloth(String name, String type, String size, double price) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("cloth_name", name);
        cv.put("cloth_type", type);
        cv.put("size", size);
        cv.put("price", price);
        return db.insert(TABLE_CLOTH, null, cv) != -1;
    }


    public long addBooking(int userId, int productId, String productType, int qty, double total) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user_id", userId);
        cv.put("product_id", productId);
        cv.put("product_type", productType);
        cv.put("quantity", qty);
        cv.put("total_price", total);
        cv.put("payment_status", "Pending");
        cv.put("booking_date", new SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(new Date()));
        return db.insert(TABLE_BOOKING, null, cv);
    }

    public void updateBookingPaymentStatus(long bookingId, String status) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("payment_status", status);
        db.update(TABLE_BOOKING, cv, "booking_id=?", new String[]{String.valueOf(bookingId)});
    }

    public List<String[]> getBookingsByUser(int userId) {
        List<String[]> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_BOOKING + " WHERE user_id=? ORDER BY booking_id DESC",
                new String[]{String.valueOf(userId)});
        while (c.moveToNext()) {
            list.add(new String[]{
                c.getString(0), c.getString(1), c.getString(2),
                c.getString(3), c.getString(4), c.getString(5),
                c.getString(6), c.getString(7)
            });
        }
        c.close();
        return list;
    }

    public List<String[]> getAllBookings() {
        List<String[]> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_BOOKING + " ORDER BY booking_id DESC", null);
        while (c.moveToNext()) {
            list.add(new String[]{
                c.getString(0), c.getString(1), c.getString(2),
                c.getString(3), c.getString(4), c.getString(5),
                c.getString(6), c.getString(7)
            });
        }
        c.close();
        return list;
    }


    public void addPayment(int userId, long bookingId, String method, double amount) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user_id", userId);
        cv.put("booking_id", bookingId);
        cv.put("payment_method", method);
        cv.put("amount", amount);
        cv.put("payment_status", "Paid");
        cv.put("payment_date", new SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(new Date()));
        db.insert(TABLE_PAYMENT, null, cv);
    }
}
