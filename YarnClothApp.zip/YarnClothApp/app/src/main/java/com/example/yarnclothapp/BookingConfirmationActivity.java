package com.example.yarnclothapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BookingConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_confirmation);
        setTitle("Booking Confirmed");

        long bookingId      = getIntent().getLongExtra("booking_id", 0);
        String paymentMethod = getIntent().getStringExtra("payment_method");
        double total        = getIntent().getDoubleExtra("total", 0);

        TextView tvBookingId     = findViewById(R.id.tvBookingId);
        TextView tvPaymentMethod = findViewById(R.id.tvPaymentMethod);
        TextView tvTotalAmount   = findViewById(R.id.tvTotalAmount);
        Button btnGoHome         = findViewById(R.id.btnGoHome);
        Button btnViewHistory    = findViewById(R.id.btnViewHistory);

        tvBookingId.setText("Booking ID: #" + bookingId);
        tvPaymentMethod.setText("Payment Method: " + paymentMethod);
        tvTotalAmount.setText("Total Paid: ₹" + total);

        btnGoHome.setOnClickListener(v -> {
            startActivity(new Intent(this, HomeActivity.class));
            finish();
        });

        btnViewHistory.setOnClickListener(v -> {
            startActivity(new Intent(this, BookingHistoryActivity.class));
            finish();
        });
    }
}
