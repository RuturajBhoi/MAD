package com.example.yarnclothapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class CartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        setTitle("My Cart");

        ListView lvCart          = findViewById(R.id.lvCart);
        TextView tvTotal         = findViewById(R.id.tvTotal);
        Button btnProceedPayment = findViewById(R.id.btnProceedPayment);

        List<CartManager.CartItem> items = CartManager.getInstance().getItems();

        if (items.isEmpty()) {
            Toast.makeText(this, "Your cart is empty!", Toast.LENGTH_SHORT).show();
        }

        List<String> displayList = new ArrayList<>();
        for (CartManager.CartItem item : items) {
            displayList.add(item.toString());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, displayList);
        lvCart.setAdapter(adapter);

        double total = CartManager.getInstance().getTotal();
        tvTotal.setText("Total: ₹" + total);

        btnProceedPayment.setOnClickListener(v -> {
            if (items.isEmpty()) {
                Toast.makeText(this, "Cart is empty! Add products first.", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(this, PaymentActivity.class);
                intent.putExtra("total", total);
                startActivity(intent);
            }
        });
    }
}
