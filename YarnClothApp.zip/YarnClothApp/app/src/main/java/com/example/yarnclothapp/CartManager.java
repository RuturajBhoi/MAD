package com.example.yarnclothapp;

import java.util.ArrayList;
import java.util.List;

public class CartManager {

    private static CartManager instance;
    private final List<CartItem> items = new ArrayList<>();

    private CartManager() {}

    public static CartManager getInstance() {
        if (instance == null) instance = new CartManager();
        return instance;
    }

    public void addItem(int productId, String productType, String productName, double price, int qty) {
        // Check if already in cart
        for (CartItem item : items) {
            if (item.productId == productId && item.productType.equals(productType)) {
                item.quantity += qty;
                return;
            }
        }
        items.add(new CartItem(productId, productType, productName, price, qty));
    }

    public List<CartItem> getItems() { return items; }

    public double getTotal() {
        double total = 0;
        for (CartItem item : items) total += item.price * item.quantity;
        return total;
    }

    public void clear() { items.clear(); }

    public static class CartItem {
        public int productId;
        public String productType;
        public String productName;
        public double price;
        public int quantity;

        public CartItem(int productId, String productType, String productName, double price, int qty) {
            this.productId   = productId;
            this.productType = productType;
            this.productName = productName;
            this.price       = price;
            this.quantity    = qty;
        }

        @Override
        public String toString() {
            return productName + " (" + productType + ")\n" +
                   "Qty: " + quantity + "  |  Price: ₹" + (price * quantity);
        }
    }
}
