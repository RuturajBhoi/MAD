package com.example.yarnclothapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Show splash for 2 seconds then navigate based on session
        new Handler().postDelayed(() -> {
            android.content.SharedPreferences prefs = getSharedPreferences("session", MODE_PRIVATE);
            int userId = prefs.getInt("user_id", -1);

            if (userId != -1) {
                // User is already logged in, go to HomeActivity
                startActivity(new Intent(SplashActivity.this, HomeActivity.class));
            } else {
                // Not logged in, go to LoginActivity
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            }
            finish();
        }, 2000);
    }
}
