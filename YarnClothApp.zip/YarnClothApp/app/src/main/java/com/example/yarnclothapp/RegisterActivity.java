package com.example.yarnclothapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    EditText etName, etMobile, etEmail, etPassword, etAddress;
    Button btnRegister, btnBackLogin;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db           = new DatabaseHelper(this);
        etName       = findViewById(R.id.etName);
        etMobile     = findViewById(R.id.etMobile);
        etEmail      = findViewById(R.id.etEmail);
        etPassword   = findViewById(R.id.etPassword);
        etAddress    = findViewById(R.id.etAddress);
        btnRegister  = findViewById(R.id.btnRegister);
        btnBackLogin = findViewById(R.id.btnBackLogin);

        btnRegister.setOnClickListener(v -> {
            String name    = etName.getText().toString().trim();
            String mobile  = etMobile.getText().toString().trim();
            String email   = etEmail.getText().toString().trim();
            String pass    = etPassword.getText().toString().trim();
            String address = etAddress.getText().toString().trim();

            if (name.isEmpty() || mobile.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success = db.registerUser(name, mobile, email, pass, address);
            if (success) {
                Toast.makeText(this, "Registration successful! Please login.", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Registration failed. Email may already exist.", Toast.LENGTH_SHORT).show();
            }
        });

        btnBackLogin.setOnClickListener(v -> finish());
    }
}
