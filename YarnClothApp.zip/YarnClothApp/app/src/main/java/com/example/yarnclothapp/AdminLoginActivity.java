package com.example.yarnclothapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminLoginActivity extends AppCompatActivity {

    // Default admin credentials
    private static final String ADMIN_USER = "admin";
    private static final String ADMIN_PASS = "admin123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        setTitle("Admin Login");

        EditText etAdminUser     = findViewById(R.id.etAdminUser);
        EditText etAdminPassword = findViewById(R.id.etAdminPassword);
        Button btnAdminLogin     = findViewById(R.id.btnAdminLogin);
        Button btnBack           = findViewById(R.id.btnBack);

        btnAdminLogin.setOnClickListener(v -> {
            String user = etAdminUser.getText().toString().trim();
            String pass = etAdminPassword.getText().toString().trim();

            if (user.equals(ADMIN_USER) && pass.equals(ADMIN_PASS)) {
                Toast.makeText(this, "Admin login successful!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, AdminDashboardActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Invalid admin credentials.", Toast.LENGTH_SHORT).show();
            }
        });

        btnBack.setOnClickListener(v -> finish());
    }
}
