package com.example.yarnclothapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class AdminDashboardActivity extends AppCompatActivity {

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);
        setTitle("Admin Dashboard");

        db = new DatabaseHelper(this);

        // Yarn fields
        EditText etYarnName  = findViewById(R.id.etYarnName);
        EditText etYarnType  = findViewById(R.id.etYarnType);
        EditText etYarnQty   = findViewById(R.id.etYarnQty);
        EditText etYarnPrice = findViewById(R.id.etYarnPrice);
        Button btnAddYarn    = findViewById(R.id.btnAddYarn);

        // Cloth fields
        EditText etClothName  = findViewById(R.id.etClothName);
        EditText etClothType  = findViewById(R.id.etClothType);
        EditText etClothSize  = findViewById(R.id.etClothSize);
        EditText etClothPrice = findViewById(R.id.etClothPrice);
        Button btnAddCloth    = findViewById(R.id.btnAddCloth);

        Button btnViewBookings   = findViewById(R.id.btnViewBookings);
        ListView lvAdminBookings = findViewById(R.id.lvAdminBookings);
        Button btnAdminLogout    = findViewById(R.id.btnAdminLogout);

        btnAddYarn.setOnClickListener(v -> {
            String name = etYarnName.getText().toString().trim();
            String type = etYarnType.getText().toString().trim();
            String qty  = etYarnQty.getText().toString().trim();
            String price = etYarnPrice.getText().toString().trim();

            if (name.isEmpty() || type.isEmpty() || qty.isEmpty() || price.isEmpty()) {
                Toast.makeText(this, "Please fill all yarn fields", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean ok = db.addYarn(name, type, Double.parseDouble(qty), Double.parseDouble(price));
            Toast.makeText(this, ok ? "Yarn added successfully!" : "Failed to add yarn", Toast.LENGTH_SHORT).show();
            if (ok) { etYarnName.setText(""); etYarnType.setText(""); etYarnQty.setText(""); etYarnPrice.setText(""); }
        });

        btnAddCloth.setOnClickListener(v -> {
            String name  = etClothName.getText().toString().trim();
            String type  = etClothType.getText().toString().trim();
            String size  = etClothSize.getText().toString().trim();
            String price = etClothPrice.getText().toString().trim();

            if (name.isEmpty() || type.isEmpty() || size.isEmpty() || price.isEmpty()) {
                Toast.makeText(this, "Please fill all cloth fields", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean ok = db.addCloth(name, type, size, Double.parseDouble(price));
            Toast.makeText(this, ok ? "Cloth added successfully!" : "Failed to add cloth", Toast.LENGTH_SHORT).show();
            if (ok) { etClothName.setText(""); etClothType.setText(""); etClothSize.setText(""); etClothPrice.setText(""); }
        });

        btnViewBookings.setOnClickListener(v -> {
            List<String[]> bookings = db.getAllBookings();
            List<String> displayList = new ArrayList<>();
            for (String[] b : bookings) {
                displayList.add("Booking #" + b[0] + " | User:" + b[1] +
                        " | " + b[3] + " | Qty:" + b[4] +
                        "\n₹" + b[5] + " | " + b[6] + " | " + b[7]);
            }
            if (displayList.isEmpty()) displayList.add("No bookings yet.");
            lvAdminBookings.setAdapter(new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1, displayList));
        });

        btnAdminLogout.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}
