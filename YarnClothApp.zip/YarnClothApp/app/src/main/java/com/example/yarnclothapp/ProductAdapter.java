package com.example.yarnclothapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class ProductAdapter extends BaseAdapter {

    private final Context context;
    private final List<String[]> productList;
    private final String productType; // "Cloth" or "Yarn"

    public ProductAdapter(Context context, List<String[]> productList, String productType) {
        this.context = context;
        this.productList = productList;
        this.productType = productType;
    }

    @Override
    public int getCount() {
        return productList.size();
    }

    @Override
    public Object getItem(int position) {
        return productList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        }

        String[] product = productList.get(position);
        
        TextView tvProductName = convertView.findViewById(R.id.tvProductName);
        TextView tvProductDetails = convertView.findViewById(R.id.tvProductDetails);
        TextView tvProductPrice = convertView.findViewById(R.id.tvProductPrice);
        EditText etQuantity = convertView.findViewById(R.id.etQuantity);
        Button btnAddToCart = convertView.findViewById(R.id.btnAddToCart);

        int productId = Integer.parseInt(product[0]);
        String name = product[1];
        String type = product[2];
        double price = Double.parseDouble(product[4]);

        tvProductName.setText((productType.equals("Cloth") ? "👗 " : "🧵 ") + name);
        
        if (productType.equals("Cloth")) {
            String size = product[3];
            tvProductDetails.setText("Type: " + type + "  |  Size: " + size);
            tvProductPrice.setText("₹" + price);
        } else {
            String stock = product[3];
            tvProductDetails.setText("Type: " + type + "  |  Stock: " + stock + " kg");
            tvProductPrice.setText("₹" + price + " / kg");
        }

        // Reset EditText when view is recycled
        etQuantity.setText("1");

        btnAddToCart.setOnClickListener(v -> {
            String qtyStr = etQuantity.getText().toString().trim();
            if (qtyStr.isEmpty()) {
                Toast.makeText(context, "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
                return;
            }
            
            try {
                int quantity = Integer.parseInt(qtyStr);
                if (quantity <= 0) {
                    Toast.makeText(context, "Quantity must be greater than zero", Toast.LENGTH_SHORT).show();
                    return;
                }
                
                CartManager.getInstance().addItem(productId, productType, name, price, quantity);
                Toast.makeText(context, "Added " + quantity + " " + name + " to cart!", Toast.LENGTH_SHORT).show();
            } catch (NumberFormatException e) {
                Toast.makeText(context, "Invalid quantity format", Toast.LENGTH_SHORT).show();
            }
        });

        return convertView;
    }
}
