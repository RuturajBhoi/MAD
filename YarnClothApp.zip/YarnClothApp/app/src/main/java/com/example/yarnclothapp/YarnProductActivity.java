package com.example.yarnclothapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class YarnProductActivity extends AppCompatActivity {

    DatabaseHelper db;
    List<String[]> yarnList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yarn_product);
        setTitle("Yarn Products");

        db = new DatabaseHelper(this);
        ListView lvYarn = findViewById(R.id.lvYarn);
        Button btnGoToCart = findViewById(R.id.btnGoToCart);

        yarnList = db.getAllYarn();

        ProductAdapter adapter = new ProductAdapter(this, yarnList, "Yarn");
        lvYarn.setAdapter(adapter);

        // Tap item -> add to cart removed because the adapter handles the add button click.

        btnGoToCart.setOnClickListener(v ->
                startActivity(new Intent(this, CartActivity.class)));
    }
}
