package com.example.yarnclothapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ClothProductActivity extends AppCompatActivity {

    DatabaseHelper db;
    List<String[]> clothList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cloth_product);
        setTitle("Cloth Products");

        db = new DatabaseHelper(this);
        ListView lvCloth   = findViewById(R.id.lvCloth);
        Button btnGoToCart = findViewById(R.id.btnGoToCart);

        clothList = db.getAllCloth();

        ProductAdapter adapter = new ProductAdapter(this, clothList, "Cloth");
        lvCloth.setAdapter(adapter);

        // Item click listener removed because "Add to Cart" button inside the adapter handles it.

        btnGoToCart.setOnClickListener(v ->
                startActivity(new Intent(this, CartActivity.class)));
    }
}
