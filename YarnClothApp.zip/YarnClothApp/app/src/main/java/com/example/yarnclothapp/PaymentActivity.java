package com.example.yarnclothapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class PaymentActivity extends AppCompatActivity {

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        setTitle("Payment");

        db = new DatabaseHelper(this);

        double total = getIntent().getDoubleExtra("total", 0);

        TextView tvAmount         = findViewById(R.id.tvAmount);
        RadioGroup rgPayment      = findViewById(R.id.rgPayment);
        Button btnConfirmPayment  = findViewById(R.id.btnConfirmPayment);

        tvAmount.setText("Amount to Pay: ₹" + total);

        btnConfirmPayment.setOnClickListener(v -> {
            int selectedId = rgPayment.getCheckedRadioButtonId();
            if (selectedId == -1) {
                Toast.makeText(this, "Please select a payment method", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton rb = findViewById(selectedId);
            String paymentMethod = rb.getText().toString();

            SharedPreferences prefs = getSharedPreferences("session", MODE_PRIVATE);
            int userId = prefs.getInt("user_id", -1);

            if (userId == -1) {
                Toast.makeText(this, "Session error. Please login again.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save all cart items as bookings
            List<CartManager.CartItem> items = CartManager.getInstance().getItems();
            long lastBookingId = -1;

            for (CartManager.CartItem item : items) {
                lastBookingId = db.addBooking(userId, item.productId, item.productType,
                        item.quantity, item.price * item.quantity);
                if (lastBookingId != -1) {
                    db.updateBookingPaymentStatus(lastBookingId, "Paid");
                    db.addPayment(userId, lastBookingId, paymentMethod, item.price * item.quantity);
                }
            }

            CartManager.getInstance().clear();

            Intent intent = new Intent(this, BookingConfirmationActivity.class);
            intent.putExtra("booking_id", lastBookingId);
            intent.putExtra("payment_method", paymentMethod);
            intent.putExtra("total", total);
            startActivity(intent);
            finish();
        });
    }
}
